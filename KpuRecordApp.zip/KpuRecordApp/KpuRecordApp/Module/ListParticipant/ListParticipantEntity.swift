//
//  ListParticipantEntity.swift
//  KpuRecordApp
//
//  Created by Prizega  on 22/08/23.
//

import Foundation

struct ListParticipantModel{
    var nik: String?
    var name: String?
    
    init(){}
    
}


