//
//  InformationPresenter.swift
//  KpuRecordApp
//
//  Created by Prizega  on 22/08/23.
//

import Foundation
import UIKit

class InformationPresenter: VTPInformationProtocol{
    var view: PTVInformationProtocol?
    var interactor: PTIInformationProtocol?
    var router: PTRInformationProtocol?
    
    
}

extension InformationPresenter: ITPInformationProtocol{
    
}
