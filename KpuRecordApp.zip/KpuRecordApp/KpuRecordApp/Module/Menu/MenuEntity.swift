//
//  MenuEntity.swift
//  KpuRecordApp
//
//  Created by Prizega  on 22/08/23.
//

import Foundation
