//
//  MenuInteractor.swift
//  KpuRecordApp
//
//  Created by Prizega  on 22/08/23.
//

import Foundation
import UIKit

class MenuInteractor: PTIMenuProtocol{
    var presenter: ITPMenuProtocol?
    
}
